/* tslint:disable */
/* eslint-disable */

export class AllodGraph {
    free(): void;
    [Symbol.dispose](): void;
    classify(node_id: string, term: string, by: string, basis: string): Promise<any>;
    commit(author: string, intent: string, ops: any, envelopes: any, sign_envelope?: boolean | null): Promise<any>;
    /**
     * Phase 1 (read-only): build the changeset without signing.
     * Returns `{ changeset, hash }`. The `changeset` has no `signature` field yet.
     *
     * `key_id`: when the private key is managed by the host (e.g. an XDG key
     * file or macOS Keychain), the host knows the key record and must pass its
     * `key_id` here. When `None`, the graph's local key store is consulted
     * instead (the original behaviour for native callers).
     */
    commit_payload(author: string, intent: string, ops: any, key_id?: string | null): any;
    /**
     * Phase 2 (mutating): attach the external signature and submit.
     * `changeset` is the plain JS object from `commit_payload` (no `signature` yet).
     * `signature` is the `sig:ed25519:<hex>` string.
     * `envelopes` is an array of attestation envelopes (may be empty).
     */
    commit_signed(changeset: any, signature: string, envelopes: any): Promise<any>;
    decide(hash: string, by: string, verdict: string): Promise<any>;
    /**
     * Phase 1 (read-only): build an unsigned decision record and the payload
     * string the decider must sign. Returns `{ record, payload }`.
     */
    decide_payload(hash: string, verdict: string): any;
    /**
     * Phase 2 (mutating): submit a signed decision record (with `deciders` populated).
     * `record` is a plain JS object matching the decision-record shape.
     */
    decide_with_record(hash: string, record: any): Promise<any>;
    describe_schema(): any;
    /**
     * Return `{ classifications, edges_out, edges_in }` for the node with the
     * given bare UUID. Walks the fold state to collect:
     *   - `classifications`: all live classification objects whose `subject == "node:<id>"`
     *   - `edges_out`: all live edge objects whose `from == "node:<id>"`
     *   - `edges_in`:  all live edge objects whose `to   == "node:<id>"`
     *
     * Returns `null` if the node is not live in fold state.
     */
    entity_context(node_id: string): any;
    /**
     * Build the unsigned attestation envelope and signing payload for an external signer.
     * Returns `{ envelope, payload }`.
     */
    envelope_payload(author: string, cs_hash: string): any;
    export_md(): any;
    /**
     * Return the graph's active policy as a plain JS object, or `null` if no
     * policy node is installed.
     *
     * `Graph::policy()` returns `Result<serde_yaml::Value, String>`. We map
     * the error case (no policy) to `null` rather than throwing, so callers
     * can do `const p = graph.get_policy(); if (p) { ... }`.
     */
    get_policy(): any;
    /**
     * Evaluate git-substrate policy rules against a proposed change.
     * `ops` is a JS array of `[verb, path]` pairs.
     * Returns `{ matched: string[], checklist: <serialised Checklist> }`.
     */
    git_checklist(repo: string, target_ref: string, ops: any): any;
    /**
     * Attach a decider `{principal, signature}` to a decision record (read-only helper).
     * Returns the updated record as a plain JS object.
     */
    git_decision_attach(record: any, principal: string, signature: string): any;
    /**
     * Build an unsigned decision record and signing payload for a git subject.
     * Returns `{ record, payload }`.
     */
    git_decision_payload(subject: string, verdict: string): any;
    /**
     * Check which reviewer requirements are unmet given a set of decision records.
     * `checklist` is the plain JS object from `git_checklist().checklist`.
     * `decisions` is an array of decision record values.
     * Returns `{ unmet: string[] }`.
     */
    git_satisfaction(subject: string, checklist: any, decisions: any): any;
    init(owner: string, profile: string): Promise<any>;
    /**
     * Install a schema package into the graph as meta-typed nodes.
     *
     * `docs_yaml` is a YAML mapping of `{name: doc}` pairs (one entry per
     * ontology / taxonomy document). `by` is the principal name performing
     * the installation. Returns the admission outcome as a JsValue.
     */
    install_package(docs_yaml: string, by: string): Promise<any>;
    /**
     * Install a new policy into the graph by parsing `policy_yaml` and calling
     * `install_package` with an empty doc set and `Some(policy)`.
     *
     * Under the reference memory policy, policy changes require the owner's
     * `decide` record, so agent-signed calls return `Held`.  Owner-signed calls
     * may also be held if `schema-changes-are-serious` is active.
     *
     * `by` is the principal name whose keypair signs the changeset.
     */
    install_policy(policy_yaml: string, by: string): Promise<any>;
    log(): any;
    /**
     * `docs`: `Array<[path, text]>` hydrating the MemStore (empty for a new graph).
     * `persist`: `async (dump: Array<[path, text]>) => void` — called and awaited
     * after every mutating call before that call resolves.
     */
    constructor(docs: any, persist: Function);
    /**
     * Return the current revision hash (`rev`) for a live node, or `null`
     * if the node is not found. The rev is needed as the `prior` field
     * in update operations.
     */
    node_rev(node_id: string): any;
    note(agent: string, content: string): Promise<any>;
    /**
     * Return the live object `{ content, rev, deleted }` from fold state for
     * (`kind`, `id`), or `null` if absent. `kind` is "node", "edge", or
     * "classification".
     */
    object_get(kind: string, id: string): any;
    principal_add(name: string, kind: string, by: string): Promise<any>;
    /**
     * Re-evaluate the admission policy for the proposal identified by `hash`
     * and return the matched rule names from the checklist. Returns an empty
     * array if the proposal does not exist or policy evaluation fails.
     */
    proposal_checklist(hash: string): any;
    /**
     * Return the full proposal changeset for `hash` (the value stored in
     * proposals/<short>.yaml), serialised as a plain JS object, or an error
     * if the proposal does not exist.
     */
    proposal_get(hash: string): any;
    proposals(): any;
    propose_preference(agent: string, statement: string, strength: string, from_note?: string | null): Promise<any>;
    state(): any;
    verify(): any;
}
